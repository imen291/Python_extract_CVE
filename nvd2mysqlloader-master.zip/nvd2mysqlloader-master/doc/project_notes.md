##NIST CVE database from JSON

Acquire and create a CVE database using the JSON provided by ['NIST CVE cache'](https://nvd.nist.gov)

(c) Mark Menkhus, 2019

